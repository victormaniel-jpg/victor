public class Calculadora {
    // Versão 1: soma dois inteiros
    public int somar(int a, int b) {
        return a + b;
    }

    // Versão 2: soma três inteiros (segunda versão "com números inteiros")
    public int somar(int a, int b, int c) {
        return a + b + c;
    }

    // Versão 3: soma dois números reais (double)
    public double somar(double a, double b) {
        return a + b;
    }

    // Versão 4: soma todos os elementos de um vetor de inteiros
    public int somar(int[] valores) {
        int total = 0;
        for (int v : valores) {
            total += v;
        }
        return total;
    }
}
