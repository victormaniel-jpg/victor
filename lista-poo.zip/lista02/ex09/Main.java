public class Main {
    public static void main(String[] args) {
        Calculadora calc = new Calculadora();

        System.out.println("somar(2, 3) = " + calc.somar(2, 3));
        System.out.println("somar(2, 3, 4) = " + calc.somar(2, 3, 4));
        System.out.println("somar(2.5, 3.7) = " + calc.somar(2.5, 3.7));
        System.out.println("somar({1,2,3,4,5}) = " + calc.somar(new int[]{1, 2, 3, 4, 5}));
    }
}
