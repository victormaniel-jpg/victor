public class Ingresso {
    private String tipo;
    private double valor;

    public Ingresso(String tipo, double valor) {
        this.tipo = tipo;
        this.valor = valor;
    }

    // Versão 1: aplica um percentual de desconto simples
    public double aplicarDesconto(double percentual) {
        return valor - (valor * percentual / 100.0);
    }

    // Versão 2: aplica o percentual, mas limita o desconto a um valor máximo.
    // Chama a versão 1 para obter o valor com desconto "cheio" e depois
    // corrige o resultado caso o desconto tenha ultrapassado o limite.
    public double aplicarDesconto(double percentual, double valorMaximoDesconto) {
        double valorComDescontoCheio = aplicarDesconto(percentual);
        double descontoCheio = valor - valorComDescontoCheio;

        if (descontoCheio > valorMaximoDesconto) {
            return valor - valorMaximoDesconto;
        }
        return valorComDescontoCheio;
    }
}
