public class Main {
    public static void main(String[] args) {
        Ingresso i1 = new Ingresso("Pista", 200.0);
        double valorFinal1 = i1.aplicarDesconto(10); // desconto simples de 10%
        System.out.println("Ingresso Pista com 10% de desconto: R$ " + valorFinal1);

        Ingresso i2 = new Ingresso("VIP", 500.0);
        double valorFinal2 = i2.aplicarDesconto(30, 50); // 30% limitado a R$50
        System.out.println("Ingresso VIP com 30% (máx. R$50) de desconto: R$ " + valorFinal2);
    }
}
