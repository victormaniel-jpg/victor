public class Main {
    public static void main(String[] args) {
        Cliente c1 = new Cliente();
        Cliente c2 = new Cliente("Maria Oliveira");
        Cliente c3 = new Cliente("João Pereira", "joao@email.com", "65999990000");

        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
    }
}
