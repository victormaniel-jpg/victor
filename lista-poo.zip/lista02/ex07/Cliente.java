public class Cliente {
    private String nome;
    private String email;
    private String telefone;

    public Cliente() {
        this("Não informado"); // encadeia para o construtor com nome
    }

    public Cliente(String nome) {
        this(nome, "não informado", "não informado"); // encadeia para o construtor completo
    }

    public Cliente(String nome, String email, String telefone) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "Cliente{nome=" + nome + ", email=" + email + ", telefone=" + telefone + "}";
    }
}
