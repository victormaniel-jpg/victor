public class Main {
    public static void main(String[] args) {
        Retangulo r1 = new Retangulo(5, 3);
        Retangulo r2 = new Retangulo(10, 2);
        Retangulo r3 = new Retangulo(7, 7);

        Retangulo[] retangulos = { r1, r2, r3 };
        int i = 1;
        for (Retangulo r : retangulos) {
            System.out.println("Retângulo " + i + " -> Área: " + r.calcularArea()
                + " | Perímetro: " + r.calcularPerimetro());
            i++;
        }
    }
}
