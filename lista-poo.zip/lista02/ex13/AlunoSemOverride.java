// Mesma classe, mas SEM sobrescrever equals/hashCode (usa a implementação
// padrão de Object, baseada na identidade/referência do objeto).
// Isso simula "comentar" os dois métodos pedidos no enunciado.
public class AlunoSemOverride {
    private int ra;
    private String nome;

    public AlunoSemOverride(int ra, String nome) {
        this.ra = ra;
        this.nome = nome;
    }
}
