import java.util.Objects;

// Versão com equals e hashCode sobrescritos, baseados no RA.
public class Aluno {
    private int ra;
    private String nome;

    public Aluno(int ra, String nome) {
        this.ra = ra;
        this.nome = nome;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Aluno outro = (Aluno) obj;
        return ra == outro.ra;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ra);
    }
}
