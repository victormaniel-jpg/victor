import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        // --- Com equals e hashCode sobrescritos ---
        HashSet<Aluno> comOverride = new HashSet<>();
        comOverride.add(new Aluno(123, "Pedro"));
        comOverride.add(new Aluno(123, "Paula")); // mesmo RA, nome diferente
        System.out.println("Com equals/hashCode sobrescritos -> tamanho do HashSet: " + comOverride.size());

        // --- Sem equals e hashCode sobrescritos (equivalente a comentar os métodos) ---
        HashSet<AlunoSemOverride> semOverride = new HashSet<>();
        semOverride.add(new AlunoSemOverride(123, "Pedro"));
        semOverride.add(new AlunoSemOverride(123, "Paula")); // mesmo RA, nome diferente
        System.out.println("Sem equals/hashCode sobrescritos -> tamanho do HashSet: " + semOverride.size());
    }
}
