import java.util.List;

public class Musica {
    private String titulo;
    private String artista;
    private int duracaoSegundos;

    public Musica(String titulo, String artista, int duracaoSegundos) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracaoSegundos = duracaoSegundos;
    }

    @Override
    public String toString() {
        int min = duracaoSegundos / 60;
        int seg = duracaoSegundos % 60;
        return titulo + " - " + artista + " (" + min + ":" + String.format("%02d", seg) + ")";
    }
}
