import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Musica m1 = new Musica("Águas de Março", "Elis Regina", 210);
        Musica m2 = new Musica("Garota de Ipanema", "Tom Jobim", 175);

        // 1) Objeto direto no println: chama toString() implicitamente
        System.out.println(m1);

        // 2) Dentro de uma concatenação de texto: também chama toString()
        System.out.println("Tocando agora: " + m2);

        // 3) Dentro de uma lista de músicas
        List<Musica> playlist = new ArrayList<>();
        playlist.add(m1);
        playlist.add(m2);
        System.out.println("Playlist: " + playlist);
    }
}
