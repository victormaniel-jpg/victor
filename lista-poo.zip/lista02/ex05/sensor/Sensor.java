package sensor;

public class Sensor {
    private double leituraBruta;

    // Método público: é o único ponto de entrada para obter uma leitura.
    public double lerValor() {
        leituraBruta = Math.random() * 100; // simula uma leitura bruta do hardware
        return calibrar();
    }

    // Método privado: só pode ser chamado de dentro da própria classe Sensor.
    private double calibrar() {
        // aplica um ajuste fixo de calibração sobre a leitura bruta
        return leituraBruta * 0.98 + 0.5;
    }
}
