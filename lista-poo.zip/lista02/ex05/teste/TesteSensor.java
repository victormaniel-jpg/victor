package teste;

import sensor.Sensor;

public class TesteSensor {
    public static void main(String[] args) {
        Sensor s = new Sensor();

        // Só temos acesso ao método público lerValor().
        // s.calibrar() e s.leituraBruta não compilariam aqui, pois são privados.
        double valor = s.lerValor();
        System.out.println("Valor calibrado obtido pelo sensor: " + valor);
    }
}
