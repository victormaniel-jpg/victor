public class Main {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("12345-6", "Carlos Souza", 1000.0);

        conta.depositar(500.0);
        System.out.println("Saldo após depósito de R$500: R$ " + conta.getSaldo());

        conta.sacar(300.0);
        System.out.println("Saldo após saque válido de R$300: R$ " + conta.getSaldo());

        conta.sacar(5000.0);
        System.out.println("Saldo após tentativa de saque de R$5000: R$ " + conta.getSaldo());
    }
}
