import java.util.Objects;

public class Ponto {
    private int x;
    private int y;

    public Ponto(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Ponto outro = (Ponto) obj;
        return x == outro.x && y == outro.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}
