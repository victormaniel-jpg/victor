public class Main {
    public static void main(String[] args) {
        Ponto p1 = new Ponto(2, 3);
        Ponto p2 = new Ponto(2, 3);
        Ponto p3 = p1; // aponta para o mesmo objeto que p1

        System.out.println("p1 == p2: " + (p1 == p2));       // false: objetos diferentes na memória
        System.out.println("p1.equals(p2): " + p1.equals(p2)); // true: mesmas coordenadas
        System.out.println("p1 == p3: " + (p1 == p3));       // true: mesma referência
        System.out.println("p1.equals(p3): " + p1.equals(p3)); // true: mesmas coordenadas (e mesma referência)
    }
}
