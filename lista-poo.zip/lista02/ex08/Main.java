public class Main {
    public static void main(String[] args) {
        Data data1 = new Data(25, 12, 2024);
        Data data2 = new Data(2025);

        System.out.println("Data 1: " + data1);
        System.out.println("Data 2: " + data2);
    }
}
