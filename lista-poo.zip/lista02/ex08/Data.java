public class Data {
    private int dia;
    private int mes;
    private int ano;

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    // Construtor que recebe apenas o ano; assume dia=1 e mes=1,
    // e chama o construtor completo via this().
    public Data(int ano) {
        this(1, 1, ano);
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + ano;
    }
}
