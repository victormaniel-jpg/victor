public class Usuario {
    private String login;
    private String senha;

    public Usuario(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }

    public void autenticar(String senhaInformada) {
        // == compara REFERÊNCIAS (endereços de memória), não o conteúdo do texto.
        // Pode dar "false" mesmo com o mesmo texto, se forem objetos String distintos.
        boolean resultadoComOperador = (senha == senhaInformada);

        // equals() compara o CONTEÚDO das strings, caractere a caractere.
        // É a forma correta de comparar senhas em Java.
        boolean resultadoComEquals = senha.equals(senhaInformada);

        System.out.println("Comparação com == : " + resultadoComOperador);
        System.out.println("Comparação com equals(): " + resultadoComEquals);
    }
}
