import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("carlos123", "senhaSegura");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite a senha:");
        String senhaDigitada = scanner.nextLine();

        usuario.autenticar(senhaDigitada);
        scanner.close();
    }
}
