public class Main {

    // Recebe a REFERÊNCIA do objeto e chama o set nela: a alteração
    // é visível fora do método, pois mexe no mesmo objeto do chamador.
    public static void trocarPlacaViaSet(Veiculo v) {
        v.setPlaca("AAA0A11");
    }

    // Cria um objeto NOVO e reatribui o parâmetro local a ele: como Java
    // passa a referência POR VALOR, isso não afeta a variável do chamador.
    public static void trocarPlacaViaNovoObjeto(Veiculo v) {
        v = new Veiculo("BBB0B22");
    }

    public static void main(String[] args) {
        Veiculo veiculo = new Veiculo("XYZ1A23");
        System.out.println("Placa inicial: " + veiculo.getPlaca());

        trocarPlacaViaSet(veiculo);
        System.out.println("Placa após trocarPlacaViaSet: " + veiculo.getPlaca());

        trocarPlacaViaNovoObjeto(veiculo);
        System.out.println("Placa após trocarPlacaViaNovoObjeto: " + veiculo.getPlaca());
    }
}
