public class Main {
    public static void main(String[] args) {
        Produto p = new Produto();
        p.setNome("Teclado Mecânico");
        p.setPreco(150.0);
        p.setQuantidade(10);

        System.out.println("Tentando atribuir valores inválidos...");
        p.setPreco(-50.0);
        p.setQuantidade(-3);

        System.out.println("\nEstado final do produto:");
        System.out.println("Nome: " + p.getNome());
        System.out.println("Preço: R$ " + p.getPreco());
        System.out.println("Quantidade: " + p.getQuantidade());
    }
}
