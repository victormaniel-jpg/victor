public class Produto {
    private String nome;
    private double preco;
    private int quantidade;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) {
        if (preco < 0) {
            System.out.println("Erro: preço não pode ser negativo. Valor rejeitado: " + preco);
            return;
        }
        this.preco = preco;
    }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) {
        if (quantidade < 0) {
            System.out.println("Erro: quantidade não pode ser menor que zero. Valor rejeitado: " + quantidade);
            return;
        }
        this.quantidade = quantidade;
    }
}
