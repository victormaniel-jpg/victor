public class Main {
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("Ana Silva", 3000.0, 500.0);
        Funcionario f2 = new Funcionario("Bruno Costa", 4200.0, 800.0);

        System.out.println(f1.getNome() + " - Salário total: R$ " + f1.getSalarioTotal());
        System.out.println(f2.getNome() + " - Salário total: R$ " + f2.getSalarioTotal());
    }
}
