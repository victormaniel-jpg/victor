public class Funcionario {
    private String nome;
    private double salarioBase;
    private double bonus;

    public Funcionario(String nome, double salarioBase, double bonus) {
        this.nome = nome;
        this.salarioBase = salarioBase;
        this.bonus = bonus;
    }

    public String getNome() { return nome; }
    public double getSalarioBase() { return salarioBase; }
    public double getBonus() { return bonus; }

    // O salário total não existe como atributo: é calculado sob demanda.
    public double getSalarioTotal() {
        return salarioBase + bonus;
    }
}
