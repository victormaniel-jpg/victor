public class Main {
    public static void main(String[] args) {
        Livro l1 = new Livro();
        l1.setTitulo("Dom Casmurro");
        l1.setAutor("Machado de Assis");
        l1.setAnoPublicacao(1899);
        l1.setPreco(35.90);

        Livro l2 = new Livro();
        l2.setTitulo("O Cortiço");
        l2.setAutor("Aluísio Azevedo");
        l2.setAnoPublicacao(1890);
        l2.setPreco(29.50);

        Livro l3 = new Livro();
        l3.setTitulo("Iracema");
        l3.setAutor("José de Alencar");
        l3.setAnoPublicacao(1865);
        l3.setPreco(24.00);

        Livro[] livros = { l1, l2, l3 };
        for (Livro l : livros) {
            System.out.println("Título: " + l.getTitulo()
                + " | Autor: " + l.getAutor()
                + " | Ano: " + l.getAnoPublicacao()
                + " | Preço: R$ " + l.getPreco());
        }
    }
}
